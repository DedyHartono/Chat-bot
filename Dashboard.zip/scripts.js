function toggleMenu() {
    const navLinks = document.querySelector(".nav-links");
    navLinks.classList.toggle("active");
  }
  
  function cardClick(featureName) {
    alert(featureName + " clicked!");
  }
  